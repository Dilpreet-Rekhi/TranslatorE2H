// backend/config/constants.js

const ROLES = {
    ADMIN: 'admin',
    USER: 'user'
  };
  
  module.exports = { ROLES };
  